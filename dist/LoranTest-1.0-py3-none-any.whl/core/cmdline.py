import argparse


def main():
    parser = argparse.ArgumentParser(description="A simple calculator")

    parser.add_argument("x", type=float, help="First number")
    parser.add_argument("y", type=float, help="Second number")
    parser.add_argument("--add", action="store_true", help="Add the two numbers")
    parser.add_argument("--subtract", action="store_true", help="Subtract the two numbers")
    parser.add_argument("--multiply", action="store_true", help="Multiply the two numbers")
    parser.add_argument("--divide", action="store_true", help="Divide the two numbers")

    args = parser.parse_args()

    if args.add:
        print(f"The sum of {args.x} and {args.y} is {args.x + args.y}")
    if args.subtract:
        print(f"The difference of {args.x} and {args.y} is {args.x - args.y}")
    if args.multiply:
        print(f"The product of {args.x} and {args.y} is {args.x * args.y}")
    if args.divide:
        if args.y != 0:
            print(f"The quotient of {args.x} and {args.y} is {args.x / args.y}")
        else:
            print("Error: Division by zero is not allowed")


if __name__ == "__main__":
    main()
