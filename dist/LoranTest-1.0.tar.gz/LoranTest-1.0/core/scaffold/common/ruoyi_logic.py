# 导入框架核心
from core.init import *

# 导入所有的logic
from common.system_management_logic import *
from common.personal_center_logic import *
from common.basic_logic import *


# 导入你编写的logic
# ......




