from loran.general_logic.excel import ExcelAssertion

def check_excel(check):
    excel_assertion = ExcelAssertion()
    excel_assertion.do_assert(check)

